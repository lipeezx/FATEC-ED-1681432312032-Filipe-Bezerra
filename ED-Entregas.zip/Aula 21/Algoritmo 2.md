﻿Algoritmo 2:

Linha 1: 1 instrução

Linhas 2-7 (loop while): 1 instrução (primeira comparação) + 1 instrução (segunda comparação) + 1 instrução (condicional) + 1 instrução (retorno) + 1 instrução (incremento) = 5 instruções

Linha 8: 1 instrução

Total de instruções para o Algoritmo 2: 7 instruções
