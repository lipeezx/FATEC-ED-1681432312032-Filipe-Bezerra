﻿Algoritmo 1:

Linha 1: 1 instrução (atribuição de valor)

Linhas 2-6 (loop for): 1 instrução (para a comparação) + 1 instrução (incremento) + 1 instrução (condicional) + 1 instrução (retorno) = 4 instruções

Linha 7: 1 instrução

Total de instruções para o Algoritmo 1: 6 instruções
