﻿Algoritmo 3:

Linha 1: 1 instrução

Linha 2: 1 instrução

Linhas 3-11 (loop while): 1 instrução (primeira comparação) + 1 instrução (condicional) + 1 instrução (cálculo do meio) + 1 instrução (condicional) + 1 instrução (retorno) + 1 instrução (segunda condicional) + 1 instrução (incremento) + 1 instrução (terceira condicional) + 1 instrução (decremento) = 9 instruções

Linha 12: 1 instrução

Total de instruções para o Algoritmo 3: 12 instruções
