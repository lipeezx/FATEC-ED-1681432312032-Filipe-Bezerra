﻿Function BuscaLinerar(A,n,x){

1 i = 1
2	Enquanto   i <= n       faça
3		Se A[i]==  x     então
4			Devolva i
5		i = i + 1
6  Devolva-1



L1 = 1 
L2 = Px vezes
L3 = Px vezes 
L4 = 1 
L5 = Px vezes - 1 
L6 = 1 

1ª posição= 5t
Última=5tn

T(n) = t + tpx + 2tpx + 2t(px-1) + t = 5tpx

